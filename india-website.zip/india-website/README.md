# 🇮🇳 India Website – Tugas Web

Website informatif tentang India yang terdiri dari 5 halaman HTML dengan CSS terpisah masing-masing.

---

## 📁 Struktur File

```
india-website/
├── index.html          → Beranda
├── sejarah.html        → Sejarah India
├── budaya.html         → Budaya India
├── kuliner.html        → Kuliner India
├── quiz.html           → Quiz tentang India
└── css/
    ├── index.css
    ├── sejarah.css
    ├── budaya.css
    ├── kuliner.css
    └── quiz.css
```

---

## 🌐 Cara Membuka

1. Buka folder `india-website`
2. Double-click `index.html` di browser
3. Navigasi antar halaman via header

---

## ✅ Checklist Fitur

| Fitur | Halaman |
|-------|---------|
| `<list>` (ul/ol/li) | Semua halaman |
| `<img>` | index, sejarah, budaya, kuliner |
| `<form>` + `<input>` | index (newsletter), quiz (nama) |
| **Text Effect** | Glitch (sejarah), Shimmer (budaya), HeatWave (kuliner), Pulse (quiz), Ticker (index) |
| **Dropdown** `<select>` | budaya (filter kategori), kuliner (tab menu) |
| **Transitions** | Semua CSS |
| **Animations** `@keyframes` | Semua CSS |
| **Grid** | Semua halaman |
| **Flex** | Semua halaman |
| **Buttons** | Semua halaman |
| **Media Query** | Semua CSS (768px & 480px) |
| **JS Function** | Semua halaman |
| **JS Events** | `addEventListener`, `onclick`, `onchange` |
| **JS Conditional** | `if/else` di semua halaman |
| **JS Looping** | `for`, `forEach` di semua halaman |

---

## 📄 Deskripsi Halaman

### 🏠 index.html (Beranda)
- Hero section dengan animasi masuk bertahap
- Cards interaktif (klik untuk expand info)
- Ticker berita berjalan otomatis
- Gallery destinasi wisata
- Form subscribe newsletter (JS validation)

### 📜 sejarah.html (Sejarah)
- **Glitch text effect** di hero title
- Timeline vertikal interaktif dengan scroll animation
- Kartu tokoh penting India
- Accordion FAQ (dropdown JS)

### 🎭 budaya.html (Budaya)
- **Mandala pulse animation** di hero
- **Dropdown filter** kategori (Tarian / Festival / Seni / Pakaian)
- Grid kartu budaya yang bisa difilter
- Agama India (6 kartu dengan scroll animation)
- Bar chart bahasa India (CSS animation)

### 🍛 kuliner.html (Kuliner)
- **Floating spice particles** animation (JS DOM)
- **Tab menu** Makanan Utama / Jajanan / Minuman / Dessert
- Food cards dengan hover image zoom
- Resep Masala Chai (toggle show/hide)

### ❓ quiz.html (Quiz)
- 10 soal pilihan ganda tentang India
- Input nama pemain wajib diisi
- Progress bar per soal
- Highlight jawaban benar/salah + penjelasan
- Animasi score circle SVG di halaman hasil
- Feedback berbeda berdasarkan skor (conditional)
- Rincian jawaban per soal (looping)

---

## 📱 Responsif
- **Desktop**: Full layout, multi-column grid
- **Tablet** (≤768px): Hamburger menu, 2-column grid
- **Mobile** (≤480px): Single column, stack layout

---

*Dibuat untuk tugas website tentang negara India*
